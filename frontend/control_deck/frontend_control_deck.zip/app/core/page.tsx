import { redirect } from "next/navigation";

export default function CoreRootPage() {
  redirect("/core/modules");
}