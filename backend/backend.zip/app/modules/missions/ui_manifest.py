UI_MANIFEST = {
    "name": "missions",
    "label": "Missions",
    "category": "Core",
    "routes": [
        {
            "path": "/control-deck/missions",
            "label": "Mission Board",
            "icon": "radar",  # optional, kann das UI ignorieren
        }
    ],
}